// SmoothBoost - Background Service Worker / Event Script (Manifest V3)
// Supports Chrome, Chromium, Titanium Browser (Android), Firefox Desktop, and Firefox Android.

try {
  if (typeof SmoothBoostCompat === "undefined" && typeof importScripts === "function") {
    importScripts("compat.js");
  }
} catch (_e) {}

const isMobilePlatform = typeof SmoothBoostCompat !== "undefined"
  ? SmoothBoostCompat.isMobile
  : (typeof navigator !== "undefined" && /android|iphone|ipad|ipod|mobile/i.test(navigator.userAgent || ""));

const DEFAULT_SETTINGS = {
  settingsVersion: 5,
  globalEnabled: true,
  mode: "auto",
  showAutoPromo: false,
  customSettings: {
    killAnimations: false,
    killTransitions: false,
    killBlurFilters: false,
    killScrollHijack: false,
    pauseBackgroundMedia: false,
    throttleCanvasFps: false,
    pauseOffscreenAnimations: false,
    contentVisibility: false,
    pauseOffscreenCanvas: false,
    passiveScroll: false,
    asyncImageDecoding: false,
    discardIdleTabs: false,
    fontDisplaySwap: false,
    fpsLimit: 30
  },
  siteOverrides: {}
};

const REGISTERED_SCRIPT_IDS = ["smoothboost-content", "smoothboost-page-hook"];
const KNOWN_PRODUCTIVITY_HOSTS = [
  "*://*.figma.com/*",
  "*://docs.google.com/*",
  "*://*.canva.com/*",
  "*://*.sketch.com/*",
  "*://*.photopea.com/*",
  "*://*.webflow.com/*",
  "*://maps.google.com/*",
  "*://earth.google.com/*"
];
const TAB_DISCARD_ALARM = "smoothboost-tab-discard";
const TAB_IDLE_THRESHOLD_MS = 30 * 60 * 1000;
let registrationQueue = Promise.resolve();

if (typeof self !== "undefined" && typeof self.addEventListener === "function") {
  self.addEventListener("unhandledrejection", (event) => {
    event.preventDefault();
  });
  self.addEventListener("error", (event) => {
    event.preventDefault();
  });
}

function getEffectiveSiteSettings(config, hostname) {
  const siteOverride = config.siteOverrides?.[hostname] || {};
  const enabled = siteOverride.enabled !== undefined ? siteOverride.enabled : config.globalEnabled !== false;
  const mode = siteOverride.mode || config.mode || "auto";
  const custom = {
    ...DEFAULT_SETTINGS.customSettings,
    ...(config.customSettings || {}),
    ...(siteOverride.customSettings || {})
  };
  return { enabled, mode, custom };
}

function toMatchPattern(hostname) {
  try {
    const normalized = new URL(`https://${hostname}`).hostname;
    if (normalized !== hostname.toLowerCase() || hostname.includes("*")) return null;
    return `*://${normalized}/*`;
  } catch (_error) {
    return null;
  }
}

async function syncDnrRules(config) {
  if (!chrome.declarativeNetRequest?.updateDynamicRules) return;
  const isEnabled = config.globalEnabled !== false &&
    (config.mode === "auto" || config.mode === "ultra" || config.customSettings?.fontDisplaySwap);
  const ruleId = 101;
  try {
    if (isEnabled) {
      await chrome.declarativeNetRequest.updateDynamicRules({
        removeRuleIds: [ruleId],
        addRules: [{
          id: ruleId,
          priority: 1,
          action: {
            type: "redirect",
            redirect: {
              transform: {
                queryTransform: {
                  addOrReplaceParams: [{ key: "display", value: "swap" }]
                }
              }
            }
          },
          condition: {
            urlFilter: "||fonts.googleapis.com/css*",
            resourceTypes: ["stylesheet"]
          }
        }]
      });
    } else {
      await chrome.declarativeNetRequest.updateDynamicRules({
        removeRuleIds: [ruleId]
      });
    }
  } catch (_error) {}
}

async function syncRegisteredScripts() {
  if (!chrome.scripting?.registerContentScripts || !chrome.scripting?.unregisterContentScripts) return;

  const { smoothBoostConfig } = await chrome.storage.local.get("smoothBoostConfig");
  const config = { ...DEFAULT_SETTINGS, ...(smoothBoostConfig || {}) };

  try {
    const existing = await chrome.scripting.getRegisteredContentScripts({ ids: REGISTERED_SCRIPT_IDS });
    const existingIds = existing.map((script) => script.id).filter((id) => REGISTERED_SCRIPT_IDS.includes(id));
    if (existingIds.length) await chrome.scripting.unregisterContentScripts({ ids: existingIds });
  } catch (_error) {
    // Continue to registration; a fresh install has no existing scripts.
  }

  const siteEntries = Object.entries(config.siteOverrides || {});
  const excludedHosts = config.globalEnabled === false ? [] : siteEntries
    .filter(([, override]) => override?.enabled === false)
    .map(([hostname]) => toMatchPattern(hostname))
    .filter(Boolean);

  const matches = config.globalEnabled === false
    ? siteEntries.filter(([, override]) => override?.enabled === true)
      .map(([hostname]) => toMatchPattern(hostname)).filter(Boolean)
    : ["<all_urls>"];
  if (!matches.length) return;

  const common = {
    matches,
    ...(excludedHosts.length ? { excludeMatches: excludedHosts } : {}),
    allFrames: false,
    runAt: "document_start"
  };

  const scripts = [
    {
      id: "smoothboost-content",
      ...common,
      js: ["scripts/content.js"],
      world: "ISOLATED"
    },
    {
      id: "smoothboost-page-hook",
      ...common,
      js: ["scripts/page-hook.js"],
      world: "MAIN"
    }
  ];

  try {
    await chrome.scripting.registerContentScripts(scripts);
  } catch (_regError) {
    try {
      await chrome.scripting.unregisterContentScripts({ ids: REGISTERED_SCRIPT_IDS });
      await chrome.scripting.registerContentScripts(scripts);
    } catch (_retryError) {
      // In environments where world: "MAIN" is unsupported (e.g. Firefox < 128),
      // register the isolated script alone. The content script handles fallback injection.
      try {
        await chrome.scripting.registerContentScripts([scripts[0]]);
      } catch (_fallbackError) {}
    }
  }

  await syncDnrRules(config);
}

function queueScriptSync() {
  registrationQueue = registrationQueue.catch(() => {}).then(syncRegisteredScripts).catch(() => {});
  return registrationQueue;
}

const UPDATE_CHECK_ALARM = "smoothboost-check-updates";

function setupAlarms() {
  if (!chrome.alarms?.create) return;
  try {
    chrome.alarms.create(TAB_DISCARD_ALARM, { periodInMinutes: 15 });
    chrome.alarms.create(UPDATE_CHECK_ALARM, { periodInMinutes: 240 });
  } catch (_error) {}
}

async function checkBackgroundUpdates() {
  try {
    const currentVersion = chrome.runtime.getManifest?.()?.version;
    if (!currentVersion) return;

    let tag = null;
    let hasZip = false;
    let zipName = null;

    try {
      const response = await fetch("https://api.github.com/repos/BiniFn/SmoothBoost/releases/latest", {
        headers: { Accept: "application/vnd.github+json" }
      });
      if (response && response.ok) {
        const release = await response.json();
        tag = release?.tag_name;
        if (Array.isArray(release?.assets)) {
          const matched = release.assets.find((a) => a?.name?.endsWith(".zip") && a.name.toLowerCase().includes("smoothboost"));
          if (matched) {
            hasZip = true;
            zipName = matched.name;
          }
        }
      }
    } catch (_apiErr) {}

    if (!tag) {
      try {
        const pageRes = await fetch("https://github.com/BiniFn/SmoothBoost/releases/latest", { redirect: "follow" });
        const tagMatch = /\/releases\/tag\/([^/?#]+)/.exec(pageRes?.url || "");
        if (tagMatch) {
          tag = decodeURIComponent(tagMatch[1]);
          const assetsRes = await fetch(`https://github.com/BiniFn/SmoothBoost/releases/expanded_assets/${encodeURIComponent(tag)}`);
          if (assetsRes && assetsRes.ok) {
            const html = await assetsRes.text();
            const zipMatch = /href="\/[^"]*\/releases\/download\/([^"']+)\/(SmoothBoost-[^"']+\.zip)"/i.exec(html);
            if (zipMatch) {
              hasZip = true;
              zipName = zipMatch[2];
            }
          }
        }
      } catch (_fbErr) {}
    }

    if (!tag) return;
    const vMatch = /^v?(\d{1,3}(?:\.\d{1,3}){0,2})/.exec(tag);
    if (!vMatch) return;
    let parsedTag = vMatch[1];
    // Ensure at least 3 parts for consistency
    const parts = parsedTag.split(".");
    while (parts.length < 3) parts.push("0");
    parsedTag = parts.join(".");

    await chrome.storage.local.set({
      smoothBoostLatestReleaseCheck: {
        checkedAt: Date.now(),
        latestVersion: parsedTag,
        hasZip,
        tag,
        zipFileName: zipName
      }
    });
  } catch (_e) {}
}

async function checkAndDiscardIdleTabs() {
  if (isMobilePlatform) return; // Android OS Low Memory Killer manages memory; extensions should not call tabs.discard
  if (!chrome.tabs?.query || !chrome.tabs?.discard) return;
  try {
    const { smoothBoostConfig } = await chrome.storage.local.get("smoothBoostConfig");
    const config = { ...DEFAULT_SETTINGS, ...(smoothBoostConfig || {}) };
    if (config.globalEnabled === false || !config.customSettings?.discardIdleTabs) return;

    const tabs = await chrome.tabs.query({});
    const now = Date.now();
    for (const tab of tabs) {
      if (
        tab.id &&
        !tab.active &&
        !tab.pinned &&
        !tab.audible &&
        !tab.discarded &&
        tab.url &&
        /^https?:\/\//i.test(tab.url) &&
        tab.lastAccessed &&
        now - tab.lastAccessed > TAB_IDLE_THRESHOLD_MS
      ) {
        try {
          await chrome.tabs.discard(tab.id);
        } catch (_discardError) {}
      }
    }
  } catch (_error) {}
}

if (chrome.alarms?.onAlarm) {
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === TAB_DISCARD_ALARM) {
      return checkAndDiscardIdleTabs().catch(() => {});
    }
    if (alarm.name === UPDATE_CHECK_ALARM) {
      return checkBackgroundUpdates().catch(() => {});
    }
  });
}

async function syncBundledSiteRules() {
  try {
    const url = chrome.runtime.getURL("data/site-rules.json");
    const res = await fetch(url);
    if (res.ok) {
      const rules = await res.json();
      await chrome.storage.local.set({ smoothBoostSiteRules: rules });
    }
  } catch (_e) {}
}

// Initialize settings and ensure dynamic registrations follow the saved site
// state after installs, upgrades, service-worker restarts, and settings edits.
chrome.runtime.onInstalled.addListener(async ({ reason } = {}) => {
  try {
    setupAlarms();
    syncBundledSiteRules().catch(() => {});
    checkBackgroundUpdates().catch(() => {});
    const existing = await chrome.storage.local.get("smoothBoostConfig");
    const current = existing?.smoothBoostConfig;

    if (!current) {
      await chrome.storage.local.set({ smoothBoostConfig: DEFAULT_SETTINGS });
    } else if (reason === "update" && (current.settingsVersion || 0) < DEFAULT_SETTINGS.settingsVersion) {
      const previousVersion = current.settingsVersion || 0;
      const upgradedCustom = {
        ...DEFAULT_SETTINGS.customSettings,
        ...(current.customSettings || {})
      };
      if (previousVersion < 2) {
        upgradedCustom.killAnimations = false;
        upgradedCustom.killTransitions = false;
        upgradedCustom.killBlurFilters = false;
        upgradedCustom.killScrollHijack = false;
        upgradedCustom.pauseBackgroundMedia = false;
      }
      const shouldShowPromo = previousVersion < 4;
      await chrome.storage.local.set({
        smoothBoostConfig: {
          ...current,
          settingsVersion: DEFAULT_SETTINGS.settingsVersion,
          showAutoPromo: shouldShowPromo,
          customSettings: upgradedCustom,
          siteOverrides: current.siteOverrides || {}
        }
      });
    }

    await queueScriptSync();

    if (chrome.scripting?.executeScript && chrome.tabs?.query) {
      try {
        const tabs = await chrome.tabs.query({ url: ["http://*/*", "https://*/*"] });
        for (const tab of tabs) {
          if (!tab.id) continue;
          chrome.scripting.executeScript({
            target: { tabId: tab.id },
            files: ["scripts/content.js"]
          }).catch(() => {});
        }
      } catch (_e) {}
    }
  } catch (_error) {
    // Avoid unhandled rejection in background service worker
  }
});

chrome.runtime.onStartup?.addListener(() => {
  setupAlarms();
  syncBundledSiteRules().catch(() => {});
  checkBackgroundUpdates().catch(() => {});
  queueScriptSync().catch(() => {});
});

chrome.storage.onChanged?.addListener((changes, areaName) => {
  if (areaName === "local" && changes.smoothBoostConfig) {
    queueScriptSync().catch(() => {});
  }
});

// Proactively synchronize registered content scripts on service worker start
queueScriptSync().catch(() => {});

// Update the toolbar badge for the active site.
async function updateBadge(tabId, url) {
  const actionApi = chrome.action || chrome.browserAction;
  if (!actionApi?.setBadgeText) return;
  if (!url || !url.startsWith("http")) {
    try {
      await actionApi.setBadgeText({ tabId, text: "" });
    } catch (_error) {}
    return;
  }

  try {
    const domain = new URL(url).hostname;
    const { smoothBoostConfig } = await chrome.storage.local.get("smoothBoostConfig");
    const config = { ...DEFAULT_SETTINGS, ...(smoothBoostConfig || {}) };
    const { enabled, mode } = getEffectiveSiteSettings(config, domain);

    let badgeText = "OFF";
    let badgeColor = "#6b7280";
    if (enabled) {
      if (mode === "auto") {
        badgeText = "AUTO";
        badgeColor = "#06b6d4";
      } else if (mode === "ultra") {
        badgeText = "MAX";
        badgeColor = "#10b981";
      } else if (mode === "balanced") {
        badgeText = "BAL";
        badgeColor = "#3b82f6";
      } else if (mode === "battery") {
        badgeText = "BATT";
        badgeColor = "#f59e0b";
      } else {
        badgeText = "ON";
        badgeColor = "#10b981";
      }
    }

    await actionApi.setBadgeText({ tabId, text: badgeText });
    if (actionApi.setBadgeBackgroundColor) {
      await actionApi.setBadgeBackgroundColor({ tabId, color: badgeColor });
    }
  } catch (_error) {
    // Ignore invalid or browser-owned URLs or closed tabs.
  }
}

chrome.tabs.onActivated.addListener(async ({ tabId }) => {
  try {
    const tab = await chrome.tabs.get(tabId);
    if (tab?.url) await updateBadge(tabId, tab.url);
  } catch (_error) {}
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete" && tab?.url) {
    updateBadge(tabId, tab.url).catch(() => {});
  }
});

function sendTabMessage(tabId, message) {
  let settled = false;
  const finish = () => { settled = true; };
  try {
    const result = chrome.tabs.sendMessage(tabId, message, { frameId: 0 }, () => {
      void chrome.runtime.lastError;
      finish();
    });
    if (result && typeof result.catch === "function") result.catch(finish);
  } catch (_error) {
    finish();
  }
  return settled;
}

chrome.runtime.onMessage?.addListener((message, _sender, sendResponse) => {
  if (message?.type === "SYNC_CONTENT_SCRIPTS") {
    queueScriptSync().then(() => sendResponse({ success: true })).catch(() => sendResponse({ success: false }));
    return true;
  }
  if (message?.type === "INJECT_PAGE_HOOK" && _sender?.tab?.id) {
    const tabId = _sender.tab.id;
    if (chrome.scripting?.executeScript) {
      chrome.scripting.executeScript({
        target: { tabId },
        world: "MAIN",
        files: ["scripts/page-hook.js"]
      }).then(() => {
        sendResponse({ injected: true });
      }).catch((_err) => {
        sendResponse({ injected: false });
      });
      return true;
    }
    sendResponse({ injected: false });
    return false;
  }
  if (message?.type === "PURGE_ARCHETYPE" && message.hostname) {
    chrome.storage.local.get("smoothBoostArchetypes").then(({ smoothBoostArchetypes }) => {
      if (smoothBoostArchetypes && smoothBoostArchetypes[message.hostname]) {
        delete smoothBoostArchetypes[message.hostname];
        chrome.storage.local.set({ smoothBoostArchetypes });
      }
    }).catch(() => {});
    sendResponse({ success: true });
    return true;
  }
  return false;
});

// Handle keyboard shortcut (Alt+Shift+S / Option+Shift+S) on desktop platforms.
if (chrome.commands?.onCommand?.addListener) {
  chrome.commands.onCommand.addListener(async (command) => {
    if (command !== "toggle-speed-boost") return;
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab?.url || !/^https?:\/\//i.test(tab.url)) return;

      const domain = new URL(tab.url).hostname;
      const { smoothBoostConfig } = await chrome.storage.local.get("smoothBoostConfig");
      const config = { ...DEFAULT_SETTINGS, ...(smoothBoostConfig || {}) };
      const current = getEffectiveSiteSettings(config, domain).enabled;
      config.siteOverrides = {
        ...(config.siteOverrides || {}),
        [domain]: { ...(config.siteOverrides?.[domain] || {}), enabled: !current }
      };

      await chrome.storage.local.set({ smoothBoostConfig: config });
      await queueScriptSync();
      await updateBadge(tab.id, tab.url);
      sendTabMessage(tab.id, { type: "CONFIG_UPDATED", config });
    } catch (_error) {}
  });
}
