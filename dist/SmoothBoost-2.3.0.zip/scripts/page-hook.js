// Runs in the page's MAIN world only on sites where SmoothBoost is enabled.
// The bridge uses a random per-document event name and accepts commands only;
// it never receives site settings or extension data. The name is not secret.

(function () {
  'use strict';

  if (window.__smoothboostHookInstalled) return;
  window.__smoothboostHookInstalled = true;

  const CHANNEL_ATTRIBUTE = 'data-smoothboost-channel';
  const REANIME_HERO_SELECTOR = '[aria-label="Hero carousel"], [aria-label*="hero carousel" i], [data-testid*="hero-carousel" i]';
  const isReanime = window === window.top && window.location?.hostname?.toLowerCase() === 'reanime.to';
  const nativeSetInterval = window.setInterval;
  const nativeClearInterval = window.clearInterval;
  const nativeSetTimeout = window.setTimeout;
  const nativeClearTimeout = window.clearTimeout;
  let optimizationsEnabled = false;
  let passiveScrollEnabled = false;
  let adaptiveLimitEnabled = false;
  let throttling = false;
  let carouselObserver = null;
  let carouselMutationObserver = null;
  let pausedCarouselInstances = new Map();
  let lastCarouselInteractionAt = 0;
  let pausedCarouselInterval = null;
  let reanimeCarouselPaused = false;
  let adaptiveObserver = null;
  let adaptiveAssessmentTimer = 0;
  let adaptiveInputUntil = 0;
  let adaptiveLastPressureAt = 0;
  let adaptiveLastThrottleAt = 0;
  let adaptivePressureTimes = [];
  let adaptiveGuardsInstalled = false;
  const activeMediaElements = new Set();

  const ADAPTIVE_PRESSURE_WINDOW_MS = 8000;
  const ADAPTIVE_PRESSURE_THRESHOLD = 3;
  const ADAPTIVE_RECOVERY_MS = 6000;
  const ADAPTIVE_THROTTLE_LEASE_MS = 5000;
  const ADAPTIVE_COOLDOWN_MS = 12000;
  const ADAPTIVE_INPUT_GRACE_MS = 1200;
  const ADAPTIVE_EXCLUDED_HOSTS = ['discord.com', 'discordapp.com', 'ws.ryuo.to'];

  const carouselIntervals = new Map();
  const frameHooks = { requestOriginal: null, requestWrapper: null, cancelOriginal: null, cancelWrapper: null };
  const pendingFrames = new Map();
  let lastFrameTime = 0;

  function makeChannelName() {
    const bytes = new Uint8Array(16);
    try { window.crypto.getRandomValues(bytes); }
    catch (_error) { for (let index = 0; index < bytes.length; index += 1) bytes[index] = Math.floor(Math.random() * 256); }
    return `__smoothboost_${Array.from(bytes, (byte) => byte.toString(16).padStart(2, '0')).join('')}`;
  }

  const channelName = makeChannelName();

  function markRootInstalled() {
    const root = document.documentElement;
    if (root) {
      root.setAttribute('data-smoothboost-hook-installed', 'true');
      root.setAttribute(CHANNEL_ATTRIBUTE, channelName);
      try {
        window.dispatchEvent(new CustomEvent('__smoothboost_page_hook_ready__'));
      } catch (_e) {}
      return true;
    }
    return false;
  }

  if (!markRootInstalled()) {
    if (document.readyState === 'loading') {
      document.addEventListener('readystatechange', () => markRootInstalled(), { once: true });
      document.addEventListener('DOMContentLoaded', () => markRootInstalled(), { once: true });
    }
  }

  function publishCarouselStatus(status) {
    if (!isReanime) return;
    window.dispatchEvent(new CustomEvent(channelName, { detail: { action: 'carousel-status', status } }));
  }

  function getHeroCarousel() {
    if (!isReanime) return null;
    return document.querySelector(REANIME_HERO_SELECTOR);
  }

  function getHeroTitle(carousel) {
    if (!carousel) return '';
    const image = carousel.querySelector('img[alt]');
    if (image?.alt?.trim()) return image.alt.trim();
    return carousel.querySelector('h1, h2, h3')?.textContent?.trim() || '';
  }

  function findHeroSlideButton(carousel, title) {
    if (!carousel || !title) return null;
    return [...carousel.querySelectorAll('button')].find((button) => {
      const accessibleName = button.getAttribute('aria-label') || button.getAttribute('title') || '';
      return accessibleName === `Go to ${title}` || button.textContent?.trim() === `Go to ${title}`;
    }) || null;
  }

  function resumePausedCarouselInterval() {
    const state = pausedCarouselInterval;
    pausedCarouselInterval = null;
    reanimeCarouselPaused = false;
    if (!state || state.clearedByPage || !getHeroCarousel()) {
      if (state) carouselIntervals.delete(state.id);
      return;
    }
    state.paused = false;
    carouselIntervals.delete(state.id);
    window.setInterval(state.callback, state.delay, ...state.args);
    publishCarouselStatus('waiting');
  }

  function pauseCarouselInterval(state, carousel, previousTitle) {
    if (state.paused || pausedCarouselInterval) return;
    state.paused = true;
    nativeClearInterval.call(window, state.id);
    pausedCarouselInterval = state;
    reanimeCarouselPaused = true;
    if (Date.now() - lastCarouselInteractionAt >= 1200 && getHeroTitle(carousel) !== previousTitle) {
      findHeroSlideButton(carousel, previousTitle)?.click();
    }
    publishCarouselStatus('paused');
  }

  function installReanimeTimerGuard() {
    if (!isReanime || typeof nativeSetInterval !== 'function' || typeof nativeClearInterval !== 'function') return;
    window.addEventListener('pointerdown', (event) => {
      if (event.isTrusted && getHeroCarousel()?.contains(event.target)) lastCarouselInteractionAt = Date.now();
    }, true);
    window.addEventListener('keydown', (event) => {
      if (event.isTrusted && getHeroCarousel()?.contains(document.activeElement)) lastCarouselInteractionAt = Date.now();
    }, true);

    window.setInterval = function (callback, delay, ...args) {
      const intervalDelay = Number(delay);
      if (reanimeCarouselPaused || typeof callback !== 'function' || !Number.isFinite(intervalDelay) || intervalDelay < 2000 || intervalDelay > 15000) {
        return nativeSetInterval.call(window, callback, delay, ...args);
      }
      const state = { callback, delay, args, id: null, paused: false, clearedByPage: false, checkPending: false };
      const wrappedCallback = function (...callbackArgs) {
        if (state.paused || reanimeCarouselPaused || !optimizationsEnabled) return callback.apply(this, callbackArgs);
        const carousel = getHeroCarousel();
        const previousTitle = getHeroTitle(carousel);
        const result = callback.apply(this, callbackArgs);
        if (!previousTitle || state.checkPending) return result;
        state.checkPending = true;
        nativeSetTimeout.call(window, () => {
          state.checkPending = false;
          if (state.paused || reanimeCarouselPaused || !optimizationsEnabled) return;
          const activeCarousel = getHeroCarousel();
          const currentTitle = getHeroTitle(activeCarousel);
          if (activeCarousel === carousel && currentTitle && currentTitle !== previousTitle) {
            pauseCarouselInterval(state, carousel, previousTitle);
          }
        }, 80);
        return result;
      };
      state.id = nativeSetInterval.call(window, wrappedCallback, delay, ...args);
      carouselIntervals.set(state.id, state);
      return state.id;
    };

    window.clearInterval = function (id) {
      const state = carouselIntervals.get(id);
      if (state) {
        state.clearedByPage = true;
        carouselIntervals.delete(id);
      }
      return nativeClearInterval.call(window, id);
    };
  }

  function carouselElement(target) {
    if (target?.getAttribute?.('data-smoothboost-carousel') === 'true') return target;
    return target?.closest?.('[data-smoothboost-carousel="true"]') || null;
  }

  function observeCarouselElement(element) {
    if (element?.getAttribute?.('data-smoothboost-carousel') === 'true') carouselObserver?.observe(element);
  }

  function startOffscreenCarousels() {
    carouselObserver?.disconnect();
    carouselMutationObserver?.disconnect();
    carouselObserver = null;
    carouselMutationObserver = null;
    pausedCarouselInstances = new Map();
    if (!optimizationsEnabled || typeof IntersectionObserver !== 'function') return;

    carouselObserver = new IntersectionObserver((entries) => {
      for (const entry of entries) {
        const element = entry.target;
        const instance = element.swiper;
        const autoplay = instance?.autoplay;
        if (!autoplay) continue;
        if (!entry.isIntersecting && autoplay.running && typeof autoplay.stop === 'function') {
          autoplay.stop();
          pausedCarouselInstances.set(element, instance);
        } else if (entry.isIntersecting && pausedCarouselInstances.get(element) === instance) {
          pausedCarouselInstances.delete(element);
          if (typeof autoplay.start === 'function') autoplay.start();
        }
      }
    }, { threshold: 0.01 });

    document.querySelectorAll('[data-smoothboost-carousel="true"]').forEach(observeCarouselElement);
    if (typeof MutationObserver === 'function' && document.documentElement) {
      carouselMutationObserver = new MutationObserver((mutations) => {
        for (const mutation of mutations) {
          if (mutation.type === 'attributes') observeCarouselElement(mutation.target);
          mutation.addedNodes?.forEach((node) => {
            if (node.nodeType !== 1) return;
            observeCarouselElement(node);
            node.querySelectorAll?.('[data-smoothboost-carousel="true"]').forEach(observeCarouselElement);
          });
        }
      });
      carouselMutationObserver.observe(document.documentElement, {
        childList: true, subtree: true, attributes: true, attributeFilter: ['data-smoothboost-carousel']
      });
    }
  }

  function resumeOffscreenCarousels() {
    for (const [element, instance] of pausedCarouselInstances) {
      if (element.isConnected && element.swiper === instance && typeof instance.autoplay?.start === 'function') instance.autoplay.start();
    }
    pausedCarouselInstances.clear();
  }

  function restoreFrameHooks() {
    if (pendingFrames.size > 0) return;
    if (frameHooks.requestWrapper && window.requestAnimationFrame === frameHooks.requestWrapper) window.requestAnimationFrame = frameHooks.requestOriginal;
    if (frameHooks.cancelWrapper && window.cancelAnimationFrame === frameHooks.cancelWrapper) window.cancelAnimationFrame = frameHooks.cancelOriginal;
    frameHooks.requestOriginal = null;
    frameHooks.requestWrapper = null;
    frameHooks.cancelOriginal = null;
    frameHooks.cancelWrapper = null;
  }

  function syncFrameHooks() {
    if (!throttling) {
      restoreFrameHooks();
      return;
    }
    if (frameHooks.requestWrapper) return;
    if (typeof window.requestAnimationFrame !== 'function' || typeof window.cancelAnimationFrame !== 'function') return;
    frameHooks.requestOriginal = window.requestAnimationFrame;
    frameHooks.cancelOriginal = window.cancelAnimationFrame;

    frameHooks.requestWrapper = function (callback) {
      if (!adaptiveLimitEnabled || !throttling) return frameHooks.requestOriginal.call(window, callback);
      const state = { cancelled: false, externalId: null, nativeId: null };
      const schedule = () => {
        state.nativeId = frameHooks.requestOriginal.call(window, (now) => {
          if (state.cancelled) return;
          if (!adaptiveLimitEnabled || !throttling) {
            pendingFrames.delete(state.externalId);
            callback.call(window, now);
            restoreFrameHooks();
            return;
          }
          const interval = 1000 / 30;
          const elapsed = now - lastFrameTime;
          if (elapsed >= interval) {
            lastFrameTime = now - (elapsed % interval);
            pendingFrames.delete(state.externalId);
            callback.call(window, now);
            restoreFrameHooks();
          } else {
            schedule();
          }
        });
        if (state.externalId === null) {
          state.externalId = state.nativeId;
          pendingFrames.set(state.externalId, state);
        }
      };
      schedule();
      return state.externalId;
    };

    frameHooks.cancelWrapper = function (id) {
      const state = pendingFrames.get(id);
      if (!state) return frameHooks.cancelOriginal.call(window, id);
      state.cancelled = true;
      pendingFrames.delete(id);
      const result = frameHooks.cancelOriginal.call(window, state.nativeId);
      restoreFrameHooks();
      return result;
    };
    window.requestAnimationFrame = frameHooks.requestWrapper;
    window.cancelAnimationFrame = frameHooks.cancelWrapper;
  }

  function adaptiveNow() {
    return window.performance?.now?.() ?? Date.now();
  }

  function isAdaptiveThrottleExcludedHost() {
    const hostname = window.location?.hostname?.toLowerCase() || '';
    return ADAPTIVE_EXCLUDED_HOSTS.some((domain) => hostname === domain || hostname.endsWith(`.${domain}`));
  }

  function hasActiveMediaPlayback() {
    for (const media of activeMediaElements) {
      if (!media.isConnected || media.paused || media.ended) {
        activeMediaElements.delete(media);
        continue;
      }
      return true;
    }
    return false;
  }

  function isAdaptiveThrottleProtected(at = adaptiveNow()) {
    return isAdaptiveThrottleExcludedHost()
      || document.hidden
      || at < adaptiveInputUntil
      || hasActiveMediaPlayback();
  }

  function trimAdaptivePressure(at = adaptiveNow()) {
    adaptivePressureTimes = adaptivePressureTimes.filter((time) => at - time <= ADAPTIVE_PRESSURE_WINDOW_MS);
    if (!adaptivePressureTimes.length) adaptiveLastPressureAt = 0;
  }

  function releaseAdaptiveThrottle() {
    if (!throttling) return;
    throttling = false;
    syncFrameHooks();
  }

  function assessAdaptiveThrottle() {
    adaptiveAssessmentTimer = 0;
    if (!adaptiveLimitEnabled) return;

    const at = adaptiveNow();
    if (isAdaptiveThrottleProtected(at)) {
      adaptivePressureTimes = [];
      adaptiveLastPressureAt = 0;
      releaseAdaptiveThrottle();
    } else {
      trimAdaptivePressure(at);
      if (throttling) {
        const recovered = adaptiveLastPressureAt > 0
          && at - adaptiveLastPressureAt >= ADAPTIVE_RECOVERY_MS;
        const leaseExpired = at - adaptiveLastThrottleAt >= ADAPTIVE_THROTTLE_LEASE_MS;
        if (recovered || leaseExpired) releaseAdaptiveThrottle();
      } else if (
        adaptivePressureTimes.length >= ADAPTIVE_PRESSURE_THRESHOLD
        && at - adaptiveLastThrottleAt >= ADAPTIVE_COOLDOWN_MS
      ) {
        throttling = true;
        adaptiveLastThrottleAt = at;
        syncFrameHooks();
      }
    }

    adaptiveAssessmentTimer = nativeSetTimeout.call(window, assessAdaptiveThrottle, 1000);
  }

  function recordAdaptivePressure(at) {
    if (!adaptiveLimitEnabled || isAdaptiveThrottleProtected(at)) {
      adaptivePressureTimes = [];
      adaptiveLastPressureAt = 0;
      releaseAdaptiveThrottle();
      return;
    }
    adaptivePressureTimes.push(at);
    adaptiveLastPressureAt = at;
    trimAdaptivePressure(at);
    if (!adaptiveAssessmentTimer) assessAdaptiveThrottle();
  }

  function noteAdaptiveInput(event) {
    if (event.type === 'pointermove' && event.buttons === 0) return;
    adaptiveInputUntil = adaptiveNow() + ADAPTIVE_INPUT_GRACE_MS;
    adaptivePressureTimes = [];
    adaptiveLastPressureAt = 0;
    releaseAdaptiveThrottle();
  }

  function updateActiveMedia(event) {
    const media = event.target;
    if (!media || !/^(AUDIO|VIDEO)$/.test(media.tagName || '')) return;
    if (event.type === 'play') {
      activeMediaElements.add(media);
      adaptivePressureTimes = [];
      adaptiveLastPressureAt = 0;
      releaseAdaptiveThrottle();
    } else {
      activeMediaElements.delete(media);
      if (!hasActiveMediaPlayback() && !adaptiveAssessmentTimer && adaptiveLimitEnabled) {
        adaptiveAssessmentTimer = nativeSetTimeout.call(window, assessAdaptiveThrottle, 1000);
      }
    }
  }

  function handleAdaptiveVisibilityChange() {
    if (document.hidden) {
      adaptivePressureTimes = [];
      adaptiveLastPressureAt = 0;
      releaseAdaptiveThrottle();
    }
  }

  function installAdaptiveGuards() {
    if (adaptiveGuardsInstalled) return;
    adaptiveGuardsInstalled = true;
    ['pointerdown', 'pointermove', 'keydown', 'wheel', 'touchstart', 'scroll'].forEach((type) => {
      document.addEventListener(type, noteAdaptiveInput, { capture: true, passive: true });
    });
    ['play', 'pause', 'ended', 'emptied'].forEach((type) => {
      document.addEventListener(type, updateActiveMedia, true);
    });
    document.addEventListener('visibilitychange', handleAdaptiveVisibilityChange, true);

    // A one-time scan covers media that began playing before Custom mode was enabled.
    document.querySelectorAll('audio, video').forEach((media) => {
      if (!media.paused && !media.ended) activeMediaElements.add(media);
    });
  }

  function removeAdaptiveGuards() {
    if (!adaptiveGuardsInstalled) return;
    adaptiveGuardsInstalled = false;
    ['pointerdown', 'pointermove', 'keydown', 'wheel', 'touchstart', 'scroll'].forEach((type) => {
      document.removeEventListener(type, noteAdaptiveInput, true);
    });
    ['play', 'pause', 'ended', 'emptied'].forEach((type) => {
      document.removeEventListener(type, updateActiveMedia, true);
    });
    document.removeEventListener('visibilitychange', handleAdaptiveVisibilityChange, true);
    activeMediaElements.clear();
    adaptiveInputUntil = 0;
  }

  function stopAdaptiveThrottle() {
    adaptiveLimitEnabled = false;
    adaptivePressureTimes = [];
    adaptiveLastPressureAt = 0;
    adaptiveLastThrottleAt = 0;
    throttling = false;
    adaptiveObserver?.disconnect();
    adaptiveObserver = null;
    if (adaptiveAssessmentTimer) nativeClearTimeout.call(window, adaptiveAssessmentTimer);
    adaptiveAssessmentTimer = 0;
    removeAdaptiveGuards();
    syncFrameHooks();
  }

  function startAdaptiveThrottle() {
    // The isolated content script sends this action only for the explicit Custom FPS toggle.
    if (adaptiveLimitEnabled) return;
    if (isAdaptiveThrottleExcludedHost()) return;

    try {
      if (typeof PerformanceObserver !== 'function') return;
      const supported = PerformanceObserver.supportedEntryTypes || [];
      const entryType = supported.includes('long-animation-frame')
        ? 'long-animation-frame'
        : supported.includes('longtask') ? 'longtask' : '';
      if (!entryType) return;

      adaptiveLimitEnabled = true;
      adaptiveLastThrottleAt = adaptiveNow() - ADAPTIVE_COOLDOWN_MS;
      installAdaptiveGuards();
      adaptiveObserver = new PerformanceObserver((list) => {
        if (isAdaptiveThrottleProtected()) {
          adaptivePressureTimes = [];
          adaptiveLastPressureAt = 0;
          releaseAdaptiveThrottle();
          return;
        }
        list.getEntries().forEach((entry) => {
          if (entry.duration >= 50) recordAdaptivePressure(entry.startTime || adaptiveNow());
        });
      });
      adaptiveObserver.observe({ type: entryType, buffered: false });
      if (!adaptiveAssessmentTimer) {
        adaptiveAssessmentTimer = nativeSetTimeout.call(window, assessAdaptiveThrottle, 1000);
      }
    } catch (_error) {
      adaptiveObserver?.disconnect();
      adaptiveObserver = null;
      stopAdaptiveThrottle();
    }
  }

  function setOptimizations(enabled) {
    optimizationsEnabled = enabled;
    if (!enabled) {
      resumePausedCarouselInterval();
      resumeOffscreenCarousels();
    } else {
      startOffscreenCarousels();
      if (adaptiveLimitEnabled) startAdaptiveThrottle();
      if (isReanime) publishCarouselStatus(reanimeCarouselPaused ? 'paused' : 'waiting');
    }
  }

  const isMapHost = /^(maps|earth)\.google\.com$|\.openstreetmap\.org$/i.test(window.location?.hostname || '');
  const isProductivityHost = /(figma|docs\.google|canva|sketch|photopea|webflow|desmos)\.com/i.test(window.location?.hostname || '');
  let canvasGuardArmed = !isProductivityHost;
  let passiveListenersIntercepted = 0;
  let canvasDrawCallsSkipped = 0;

  function isInteractiveTarget(target) {
    if (isMapHost) return true;
    if (!target) return false;
    const tagName = target.tagName ? String(target.tagName).toUpperCase() : '';
    if (['INPUT', 'TEXTAREA', 'SELECT', 'CANVAS'].includes(tagName)) return true;
    if (target.isContentEditable) return true;
    if (typeof target.closest === 'function') {
      return !!target.closest(
        '.leaflet-container, .mapboxgl-map, [aria-roledescription="map"], canvas, [data-smoothboost-allow-prevent-default], [role="slider"], input[type="range"], .monaco-editor, .ace_editor, .cm-editor, #canvas, #unity-canvas, .game-canvas, [contenteditable="true"], [draggable="true"], [data-draggable], .draggable, .drag-handle, .swiper-slide, .scroller, [data-list-id], [data-testid*="scroller"], [role="tree"], [role="listbox"], [role="menu"], [role="dialog"], [aria-modal="true"]'
      );
    }
    return false;
  }

  function installPassiveScrollGuard() {
    const TargetProto = typeof EventTarget !== 'undefined' ? EventTarget.prototype : null;
    if (!TargetProto || typeof TargetProto.addEventListener !== 'function') return;
    const nativeAddEventListener = TargetProto.addEventListener;
    TargetProto.addEventListener = function (type, listener, options) {
      if (passiveScrollEnabled && typeof listener === 'function' &&
          (type === 'wheel' || type === 'mousewheel' || type === 'touchstart' || type === 'touchmove')) {
        if (!isInteractiveTarget(this)) {
          passiveListenersIntercepted += 1;
          let opts;
          if (typeof options === 'boolean') {
            opts = { capture: options, passive: true };
          } else if (options && typeof options === 'object') {
            opts = { ...options, passive: true };
          } else {
            opts = { passive: true };
          }
          return nativeAddEventListener.call(this, type, listener, opts);
        }
      }
      return nativeAddEventListener.call(this, type, listener, options);
    };
  }

  function shouldSkipCanvasDraw(ctx) {
    if (!canvasGuardArmed || !optimizationsEnabled) return false;
    const canvas = ctx?.canvas;
    // Never skip draws on explicitly detached buffer canvases
    if (!canvas || canvas.isConnected === false) return false;
    if (canvas.style && (canvas.style.position === 'fixed' || canvas.style.position === 'sticky')) return false;
    return canvas.getAttribute?.('data-smoothboost-offscreen-canvas') === 'true';
  }

  function installCanvasGuard() {
    if (typeof CanvasRenderingContext2D !== 'undefined' && CanvasRenderingContext2D.prototype) {
      const origClearRect = CanvasRenderingContext2D.prototype.clearRect;
      const origDrawImage = CanvasRenderingContext2D.prototype.drawImage;
      if (typeof origClearRect === 'function') {
        CanvasRenderingContext2D.prototype.clearRect = function (...args) {
          if (shouldSkipCanvasDraw(this)) {
            canvasDrawCallsSkipped += 1;
            return;
          }
          return origClearRect.apply(this, args);
        };
      }
      if (typeof origDrawImage === 'function') {
        CanvasRenderingContext2D.prototype.drawImage = function (...args) {
          if (shouldSkipCanvasDraw(this)) {
            canvasDrawCallsSkipped += 1;
            return;
          }
          return origDrawImage.apply(this, args);
        };
      }
    }

    const hookWebGL = (Context) => {
      if (typeof Context !== 'undefined' && Context?.prototype) {
        const origDrawArrays = Context.prototype.drawArrays;
        const origDrawElements = Context.prototype.drawElements;
        if (typeof origDrawArrays === 'function') {
          Context.prototype.drawArrays = function (...args) {
            if (shouldSkipCanvasDraw(this)) {
              canvasDrawCallsSkipped += 1;
              return;
            }
            return origDrawArrays.apply(this, args);
          };
        }
        if (typeof origDrawElements === 'function') {
          Context.prototype.drawElements = function (...args) {
            if (shouldSkipCanvasDraw(this)) {
              canvasDrawCallsSkipped += 1;
              return;
            }
            return origDrawElements.apply(this, args);
          };
        }
      }
    };
    hookWebGL(typeof WebGLRenderingContext !== 'undefined' ? WebGLRenderingContext : undefined);
    hookWebGL(typeof WebGL2RenderingContext !== 'undefined' ? WebGL2RenderingContext : undefined);
  }

  installReanimeTimerGuard();
  installPassiveScrollGuard();
  installCanvasGuard();
  if (isReanime) publishCarouselStatus('waiting');
  startOffscreenCarousels();

  window.addEventListener(channelName, (event) => {
    const action = event.detail?.action;
    if (action === 'optimizations-on') setOptimizations(true);
    else if (action === 'optimizations-off') setOptimizations(false);
    else if (action === 'passive-scroll-on') passiveScrollEnabled = true;
    else if (action === 'passive-scroll-off') passiveScrollEnabled = false;
    else if (action === 'adaptive-limit-on') startAdaptiveThrottle();
    else if (action === 'adaptive-limit-off') stopAdaptiveThrottle();
    else if (action === 'enable-canvas-guard') canvasGuardArmed = true;
    else if (action === 'disable-canvas-guard') canvasGuardArmed = false;
    else if (action === 'get-hook-metrics') {
      window.dispatchEvent(new CustomEvent(channelName, {
        detail: {
          action: 'hook-metrics',
          passiveListenersIntercepted,
          canvasDrawCallsSkipped
        }
      }));
    }
  });

  // This event only signals that the per-document channel is ready. The random
  // channel name itself is also stored on the DOM root so the isolated world can
  // discover it if script startup order differs.
  window.dispatchEvent(new CustomEvent('__smoothboost_page_hook_ready__'));
})();
