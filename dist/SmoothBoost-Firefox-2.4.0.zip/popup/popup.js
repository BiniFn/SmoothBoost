// SmoothBoost - popup controller (v2.4.0)

const DEFAULT_SETTINGS = {
  settingsVersion: 5,
  globalEnabled: true,
  mode: 'auto',
  showAutoPromo: false,
  customSettings: {
    killAnimations: false,
    killTransitions: false,
    killBlurFilters: false,
    killScrollHijack: false,
    pauseBackgroundMedia: false,
    throttleCanvasFps: false,
    contentVisibility: false,
    pauseOffscreenAnimations: false,
    pauseOffscreenCanvas: false,
    passiveScroll: false,
    asyncImageDecoding: false,
    discardIdleTabs: false,
    fontDisplaySwap: false,
    fpsLimit: 30,
    scrollBoost: false,
    smartResourceLoading: false,
    memoryGuard: false,
    spaOptimization: true,
    autoRecovery: true
  },
  siteOverrides: {}
};
const GITHUB_ISSUE_URL = 'https://github.com/BiniFn/SmoothBoost/issues/new';
const UPDATE_CACHE_KEY = 'smoothBoostLatestReleaseCheck';
const UPDATE_CACHE_TTL_MS = 6 * 60 * 60 * 1000;

let currentTab = null;
let currentHostname = '';
let config = null;
let lastDiagnostics = null;

const domainLabel = document.getElementById('domain-label');
const siteToggle = document.getElementById('site-toggle');
const btnAuto = document.getElementById('btn-auto');
const btnUltra = document.getElementById('btn-ultra');
const btnBalanced = document.getElementById('btn-balanced');
const btnBattery = document.getElementById('btn-battery');
const btnCustom = document.getElementById('btn-custom');
const btnExportSettings = document.getElementById('btn-export-settings');
const btnImportSettings = document.getElementById('btn-import-settings');
const inputImportSettings = document.getElementById('input-import-settings');
const settingsStatus = document.getElementById('settings-status');
const shortcutTip = document.getElementById('shortcut-tip');
const autoPromoBanner = document.getElementById('auto-promo-banner');
const btnAcceptAuto = document.getElementById('btn-accept-auto');
const btnDismissAuto = document.getElementById('btn-dismiss-auto');
const updateNotificationBanner = document.getElementById('update-notification-banner');
const updateNotificationText = document.getElementById('update-notification-text');
const updateNotificationAction = document.getElementById('update-notification-action');
const updateNotificationDismiss = document.getElementById('update-notification-dismiss');
const updateTabDot = document.getElementById('update-tab-dot');
const resetBtn = document.getElementById('reset-defaults');
const controlsTab = document.getElementById('tab-controls');
const helpTab = document.getElementById('tab-help');
const controlsPanel = document.getElementById('controls-panel');
const helpPanel = document.getElementById('help-panel');
const statusDot = document.getElementById('status-dot');
const statusPage = document.getElementById('status-page');
const statusDetail = document.getElementById('status-detail');
const statusProfile = document.getElementById('status-profile');
const statusSiteRule = document.getElementById('status-site-rule');
const siteRuleRow = document.getElementById('site-rule-row');
const metricsContainer = document.getElementById('metrics-container');
const togglesWrapper = document.getElementById('toggles-wrapper');
const toggleAnim = document.getElementById('toggle-animations');
const toggleTrans = document.getElementById('toggle-transitions');
const toggleBlur = document.getElementById('toggle-blur');
const toggleScroll = document.getElementById('toggle-scroll');
const toggleMedia = document.getElementById('toggle-media');
const toggleFps = document.getElementById('toggle-fps');
const toggleOffscreen = document.getElementById('toggle-offscreen-animations');
const toggleContentVisibility = document.getElementById('toggle-content-visibility');
const toggleOffscreenCanvas = document.getElementById('toggle-offscreen-canvas');
const togglePassiveScroll = document.getElementById('toggle-passive-scroll');
const toggleAsyncImages = document.getElementById('toggle-async-images');
const toggleScrollBoost = document.getElementById('toggle-scroll-boost');
const toggleSmartResources = document.getElementById('toggle-smart-resources');
const toggleMemoryGuard = document.getElementById('toggle-memory-guard');
const toggleSpaOptimization = document.getElementById('toggle-spa-optimization');
const toggleAutoRecovery = document.getElementById('toggle-auto-recovery');
const autoRecoveryBanner = document.getElementById('auto-recovery-banner');
const btnResetRecovery = document.getElementById('btn-reset-recovery');
const fpsButtons = {
  30: document.getElementById('btn-fps-30'),
  60: document.getElementById('btn-fps-60'),
  90: document.getElementById('btn-fps-90'),
  120: document.getElementById('btn-fps-120')
};
const siteBrokenButton = document.getElementById('site-broken');
const bugReportLink = document.getElementById('bug-report-link');
const updateStatus = document.getElementById('update-status');
const checkUpdatesButton = document.getElementById('check-updates');
const downloadUpdateLink = document.getElementById('download-update');
const releaseUpdateLink = document.getElementById('release-update-link');

const PRESET_CONFIGS = {
  auto: {
    killAnimations: false,
    killTransitions: false,
    killBlurFilters: true,
    killScrollHijack: false,
    pauseBackgroundMedia: true,
    throttleCanvasFps: false,
    pauseOffscreenAnimations: true,
    contentVisibility: false,
    pauseOffscreenCanvas: true,
    passiveScroll: true,
    asyncImageDecoding: true,
    fontDisplaySwap: true,
    scrollBoost: true,
    smartResourceLoading: true,
    memoryGuard: true,
    spaOptimization: true,
    autoRecovery: true,
    fpsLimit: 60
  },
  ultra: {
    killAnimations: false,
    killTransitions: false,
    killBlurFilters: true,
    killScrollHijack: false,
    pauseBackgroundMedia: true,
    throttleCanvasFps: false,
    pauseOffscreenAnimations: true,
    contentVisibility: false,
    pauseOffscreenCanvas: true,
    passiveScroll: true,
    asyncImageDecoding: true,
    fontDisplaySwap: true,
    scrollBoost: true,
    smartResourceLoading: true,
    memoryGuard: true,
    spaOptimization: true,
    autoRecovery: true,
    fpsLimit: 60
  },
  balanced: {
    killAnimations: false,
    killTransitions: false,
    killBlurFilters: false,
    killScrollHijack: false,
    pauseBackgroundMedia: false,
    throttleCanvasFps: false,
    pauseOffscreenAnimations: false,
    contentVisibility: false,
    pauseOffscreenCanvas: false,
    passiveScroll: false,
    asyncImageDecoding: false,
    fontDisplaySwap: false,
    scrollBoost: false,
    smartResourceLoading: false,
    memoryGuard: false,
    spaOptimization: true,
    autoRecovery: true,
    fpsLimit: 60
  },
  battery: {
    killAnimations: false,
    killTransitions: false,
    killBlurFilters: true,
    killScrollHijack: false,
    pauseBackgroundMedia: true,
    throttleCanvasFps: true,
    pauseOffscreenAnimations: true,
    contentVisibility: true,
    pauseOffscreenCanvas: true,
    passiveScroll: true,
    asyncImageDecoding: true,
    fontDisplaySwap: true,
    scrollBoost: true,
    smartResourceLoading: true,
    memoryGuard: true,
    spaOptimization: true,
    autoRecovery: true,
    fpsLimit: 30
  }
};

async function init() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  currentTab = tab || null;
  if (tab?.url && /^https?:\/\//i.test(tab.url)) {
    try {
      currentHostname = new URL(tab.url).hostname.toLowerCase();
      domainLabel.textContent = currentHostname;
    } catch (_error) {
      domainLabel.textContent = 'Current tab';
    }
  } else {
    domainLabel.textContent = 'Browser page (inactive)';
    siteToggle.disabled = true;
    siteBrokenButton.disabled = true;
  }

  const stored = await chrome.storage.local.get('smoothBoostConfig');
  config = {
    ...DEFAULT_SETTINGS,
    ...(stored.smoothBoostConfig || {}),
    customSettings: { ...DEFAULT_SETTINGS.customSettings, ...(stored.smoothBoostConfig?.customSettings || {}) },
    siteOverrides: stored.smoothBoostConfig?.siteOverrides || {}
  };
  renderUI();
  requestPageStatus();
  bindEvents();
  if (bugReportLink) bugReportLink.href = buildIssueUrl(false);
  void checkForUpdates();
}

function renderUpdateResult(result, checkedAt, note = '') {
  if (downloadUpdateLink) downloadUpdateLink.hidden = true;
  if (releaseUpdateLink) releaseUpdateLink.hidden = true;

  if (!result) {
    if (updateStatus) updateStatus.textContent = note || 'Could not read the latest GitHub release. Try again.';
    if (updateNotificationBanner) {
      updateNotificationBanner.hidden = true;
      if (updateNotificationBanner.style) updateNotificationBanner.style.display = 'none';
    }
    if (updateTabDot) {
      updateTabDot.hidden = true;
      if (updateTabDot.style) updateTabDot.style.display = 'none';
    }
    return;
  }

  const isUpdate = result.status === 'update' || result.status === 'update-without-zip';
  if (updateNotificationBanner && updateNotificationAction && updateNotificationText) {
    if (isUpdate) {
      updateNotificationText.textContent = `Update available: v${result.latestVersion}`;
      updateNotificationAction.href = result.downloadUrl || result.releaseUrl;
      updateNotificationAction.textContent = result.hasZip ? 'Download' : 'View';
      updateNotificationBanner.hidden = false;
      if (updateNotificationBanner.style) updateNotificationBanner.style.display = 'flex';
      if (updateTabDot) {
        updateTabDot.hidden = false;
        if (updateTabDot.style) updateTabDot.style.display = 'inline-block';
      }
    } else {
      updateNotificationBanner.hidden = true;
      if (updateNotificationBanner.style) updateNotificationBanner.style.display = 'none';
      if (updateTabDot) {
        updateTabDot.hidden = true;
        if (updateTabDot.style) updateTabDot.style.display = 'none';
      }
    }
  }

  const freshness = note || (checkedAt ? ` Checked ${new Date(checkedAt).toLocaleString()}.` : '');
  if (result.status === 'update') {
    if (updateStatus) updateStatus.textContent = `Update available: ${result.latestVersion}.${freshness}`;
    if (downloadUpdateLink) {
      downloadUpdateLink.href = result.downloadUrl;
      downloadUpdateLink.textContent = `Download SmoothBoost ${result.latestVersion}`;
      downloadUpdateLink.hidden = false;
    }
    return;
  }
  if (result.status === 'update-without-zip') {
    if (updateStatus) updateStatus.textContent = `Version ${result.latestVersion} is available, but its ZIP is not attached yet.${freshness}`;
    if (releaseUpdateLink) {
      releaseUpdateLink.href = result.releaseUrl;
      releaseUpdateLink.hidden = false;
    }
    return;
  }
  if (result.status === 'ahead') {
    if (updateStatus) updateStatus.textContent = `This installed version is newer than the latest GitHub release (${result.latestVersion}).${freshness}`;
    return;
  }
  if (updateStatus) updateStatus.textContent = `You're up to date (${result.currentVersion}).${freshness}`;
}

async function checkForUpdates(force = false) {
  if (!checkUpdatesButton || !updateStatus) return;
  const currentVersion = chrome.runtime.getManifest().version;
  let cached = null;
  try {
    const stored = await chrome.storage.local.get(UPDATE_CACHE_KEY);
    cached = stored[UPDATE_CACHE_KEY];
  } catch (_error) {}

  const isFresh = cached && Number.isFinite(cached.checkedAt)
    && Date.now() - cached.checkedAt >= 0
    && Date.now() - cached.checkedAt < UPDATE_CACHE_TTL_MS;
  const cachedResult = isFresh ? SmoothBoostUpdates.fromCache(currentVersion, cached) : null;
  if (!force && cachedResult) {
    renderUpdateResult(cachedResult, cached.checkedAt);
    return;
  }

  checkUpdatesButton.disabled = true;
  checkUpdatesButton.textContent = 'Checking…';
  updateStatus.textContent = 'Checking GitHub for updates…';
  const controller = new AbortController();
  const timeoutId = window.setTimeout(() => controller.abort(), 8000);

  try {
    const fetchImpl = typeof fetch === 'function' ? fetch : undefined;
    const platformKey = typeof SmoothBoostCompat !== 'undefined' && typeof SmoothBoostCompat.getPlatformKey === 'function'
      ? SmoothBoostCompat.getPlatformKey()
      : 'chrome';
    const result = await SmoothBoostUpdates.fetchLatestReleaseInfo(currentVersion, {
      signal: controller.signal,
      fetchImpl,
      platformKey
    });
    if (!result) throw new Error('Could not check GitHub');

    const checkedAt = Date.now();
    try {
      await chrome.storage.local.set({
        [UPDATE_CACHE_KEY]: {
          checkedAt,
          latestVersion: result.latestVersion,
          hasZip: result.hasZip,
          tag: result.releaseUrl ? result.releaseUrl.split('/').pop() : undefined,
          zipFileName: result.downloadUrl ? result.downloadUrl.split('/').pop() : undefined
        }
      });
    } catch (_error) {}
    renderUpdateResult(result, checkedAt);
  } catch (_error) {
    if (cachedResult) {
      renderUpdateResult(cachedResult, cached.checkedAt, 'GitHub could not be reached; showing the last checked result.');
    } else {
      renderUpdateResult(null, null, 'Could not check GitHub. Check your connection and try again.');
    }
  } finally {
    window.clearTimeout(timeoutId);
    checkUpdatesButton.disabled = false;
    checkUpdatesButton.textContent = 'Check';
  }
}

function getSiteState() {
  if (!currentHostname) return { enabled: config.globalEnabled, mode: config.mode || 'auto' };
  const override = config.siteOverrides?.[currentHostname] || {};
  return {
    enabled: override.enabled !== undefined ? override.enabled : config.globalEnabled,
    mode: override.mode || config.mode || 'auto'
  };
}

function getCustomSettings() {
  const site = currentHostname ? config.siteOverrides?.[currentHostname] : null;
  return {
    ...DEFAULT_SETTINGS.customSettings,
    ...(config.customSettings || {}),
    ...(site?.customSettings || {})
  };
}

function getEffectiveSettings() {
  const { enabled, mode } = getSiteState();
  if (!enabled) return { enabled: false, mode: 'off' };
  if (mode === 'auto') return { enabled: true, mode, ...PRESET_CONFIGS.auto };
  if (mode === 'ultra') return { enabled: true, mode, ...PRESET_CONFIGS.ultra };
  if (mode === 'balanced') return { enabled: true, mode, ...PRESET_CONFIGS.balanced };
  if (mode === 'battery') return { enabled: true, mode, ...PRESET_CONFIGS.battery };
  return { enabled: true, mode: 'custom', ...getCustomSettings() };
}

function renderUI() {
  const { enabled, mode } = getSiteState();
  siteToggle.checked = enabled;
  document.body.classList.toggle('site-disabled', !enabled);

  if (btnAuto) btnAuto.classList.toggle('active', mode === 'auto');
  if (btnUltra) btnUltra.classList.toggle('active', mode === 'ultra');
  if (btnBalanced) btnBalanced.classList.toggle('active', mode === 'balanced');
  if (btnBattery) btnBattery.classList.toggle('active', mode === 'battery');
  if (btnCustom) btnCustom.classList.toggle('active', mode === 'custom');

  if (togglesWrapper) {
    togglesWrapper.hidden = (mode !== 'custom');
  }

  if (autoPromoBanner) {
    const showPromo = Boolean(config.showAutoPromo && mode !== 'auto' && enabled);
    autoPromoBanner.hidden = !showPromo;
    if (autoPromoBanner.style) autoPromoBanner.style.display = showPromo ? 'flex' : 'none';
  }

  const custom = getCustomSettings();
  if (toggleAnim) toggleAnim.checked = custom.killAnimations;
  if (toggleTrans) toggleTrans.checked = custom.killTransitions;
  if (toggleBlur) toggleBlur.checked = custom.killBlurFilters;
  if (toggleScroll) toggleScroll.checked = custom.killScrollHijack;
  if (toggleMedia) toggleMedia.checked = custom.pauseBackgroundMedia;
  if (toggleFps) toggleFps.checked = custom.throttleCanvasFps;
  if (toggleOffscreen) toggleOffscreen.checked = custom.pauseOffscreenAnimations;
  if (toggleContentVisibility) toggleContentVisibility.checked = custom.contentVisibility;
  if (toggleOffscreenCanvas) toggleOffscreenCanvas.checked = custom.pauseOffscreenCanvas;
  if (togglePassiveScroll) togglePassiveScroll.checked = custom.passiveScroll;
  if (toggleAsyncImages) toggleAsyncImages.checked = custom.asyncImageDecoding;
  if (toggleScrollBoost) toggleScrollBoost.checked = !!custom.scrollBoost;
  if (toggleSmartResources) toggleSmartResources.checked = !!custom.smartResourceLoading;
  if (toggleMemoryGuard) toggleMemoryGuard.checked = !!custom.memoryGuard;
  if (toggleSpaOptimization) toggleSpaOptimization.checked = custom.spaOptimization !== false;
  if (toggleAutoRecovery) toggleAutoRecovery.checked = custom.autoRecovery !== false;

  const currentFps = custom.fpsLimit || (mode === 'battery' ? 30 : 60);
  Object.entries(fpsButtons).forEach(([fps, btn]) => {
    if (btn) btn.classList.toggle('is-active', Number(fps) === Number(currentFps));
  });
}

function setFpsLimit(fps) {
  if (!config.customSettings) {
    config.customSettings = { ...DEFAULT_SETTINGS.customSettings };
  }
  config.customSettings.fpsLimit = fps;
  if (currentHostname && config.siteOverrides?.[currentHostname]?.customSettings) {
    config.siteOverrides[currentHostname].customSettings.fpsLimit = fps;
  }
  renderUI();
  saveAndBroadcast();
}

function updateSiteOverride(patch) {
  if (!currentHostname) {
    Object.assign(config, patch);
    return;
  }
  const current = config.siteOverrides?.[currentHostname] || {};
  config.siteOverrides = {
    ...(config.siteOverrides || {}),
    [currentHostname]: { ...current, ...patch }
  };
}

async function saveAndBroadcast() {
  await chrome.storage.local.set({ smoothBoostConfig: config });
  if (currentTab?.id) {
    sendTabMessage(currentTab.id, { type: 'CONFIG_UPDATED', config });
    requestPageStatus();
  }
}

function setMode(mode) {
  config.mode = mode;
  if (currentHostname && config.siteOverrides?.[currentHostname]?.mode) {
    delete config.siteOverrides[currentHostname].mode;
  }
  renderUI();
  saveAndBroadcast();
}

function setCustomSetting(key, value) {
  config.mode = 'custom';
  if (!config.customSettings) {
    config.customSettings = { ...DEFAULT_SETTINGS.customSettings };
  }
  config.customSettings[key] = value;
  if (currentHostname && config.siteOverrides?.[currentHostname]?.customSettings) {
    delete config.siteOverrides[currentHostname].customSettings;
  }
  renderUI();
  saveAndBroadcast();
}

function renderRuleStatus(status) {
  if (status === 'paused') statusSiteRule.textContent = 'Paused';
  else if (status === 'waiting' || status === 'armed') statusSiteRule.textContent = 'Waiting for autoplay';
  else if (status === 'unconfirmed') statusSiteRule.textContent = 'Not confirmed';
  else statusSiteRule.textContent = 'Off';
}

function clearMetricsContainer() {
  if (!metricsContainer) return;
  if (typeof metricsContainer.replaceChildren === 'function') {
    metricsContainer.replaceChildren();
  } else {
    metricsContainer.textContent = '';
  }
}

function renderReloadStatus() {
  statusDot.className = 'status-dot is-warning';
  statusPage.textContent = 'Reload tab to activate';
  statusDetail.textContent = 'Reload this tab after installing or updating SmoothBoost.';
  statusProfile.textContent = '—';
  if (siteRuleRow) {
    siteRuleRow.hidden = true;
    if (siteRuleRow.style) siteRuleRow.style.display = 'none';
  }
  clearMetricsContainer();
}

function renderUnsupportedStatus() {
  statusDot.className = 'status-dot is-muted';
  statusPage.textContent = 'Unsupported page';
  statusDetail.textContent = 'The browser does not allow extensions to run on this page.';
  statusProfile.textContent = '—';
  if (siteRuleRow) {
    siteRuleRow.hidden = true;
    if (siteRuleRow.style) siteRuleRow.style.display = 'none';
  }
  clearMetricsContainer();
}

function renderSiteOffStatus() {
  statusDot.className = 'status-dot is-muted';
  statusPage.textContent = 'Off for this site';
  statusDetail.textContent = 'SmoothBoost is not injected here. Turn it on and reload this tab to apply it.';
  statusProfile.textContent = 'Off';
  if (siteRuleRow) {
    siteRuleRow.hidden = true;
    if (siteRuleRow.style) siteRuleRow.style.display = 'none';
  }
  clearMetricsContainer();
}

function createMetricPillElement(label, iconText) {
  const pill = document.createElement('span');
  pill.className = 'metric-pill';
  if (iconText) {
    const icon = document.createElement('span');
    icon.style.marginRight = '4px';
    icon.textContent = iconText;
    pill.appendChild(icon);
  }
  pill.appendChild(document.createTextNode(label));
  return pill;
}

function renderMetricsPills(metrics) {
  if (!metricsContainer || !metrics) return;
  clearMetricsContainer();

  const passive = Math.max(0, Math.floor(Number(metrics.passiveListeners) || 0));
  const videos = Math.max(0, Math.floor(Number(metrics.pausedVideos) || 0));
  const blurs = Math.max(0, Math.floor(Number(metrics.bypassedBlurs) || 0));
  const canvases = Math.max(0, Math.floor(Number(metrics.offscreenCanvases) || 0));
  const draws = Math.max(0, Math.floor(Number(metrics.canvasDrawsSkipped) || 0));
  const fonts = Math.max(0, Math.floor(Number(metrics.patchedFonts) || 0));

  if (passive > 0) {
    metricsContainer.appendChild(createMetricPillElement(`${passive} scroll listeners passive`, '↕️'));
  }
  if (videos > 0) {
    metricsContainer.appendChild(createMetricPillElement(`${videos} background videos paused`, '⏸️'));
  }
  if (blurs > 0) {
    metricsContainer.appendChild(createMetricPillElement(`${blurs} blur panels bypassed`, '🛡️'));
  }
  if (canvases > 0 || draws > 0) {
    metricsContainer.appendChild(createMetricPillElement('Canvas draw-skipping active', '🎨'));
  }
  if (fonts > 0) {
    metricsContainer.appendChild(createMetricPillElement(`${fonts} fonts swapped`, '🔤'));
  }
  if (metrics.scrollBoostActive) {
    metricsContainer.appendChild(createMetricPillElement('Scroll Boost active', '⚡'));
  }
  if (metrics.smartResourcesDeferred > 0) {
    metricsContainer.appendChild(createMetricPillElement(`${metrics.smartResourcesDeferred} embeds deferred`, '📦'));
  }
  if (metrics.memoryGuard?.active) {
    metricsContainer.appendChild(createMetricPillElement(`Memory Guard (${metrics.memoryGuard.pressure})`, '🛡️'));
  }
  if (metrics.spaNavigations > 0) {
    metricsContainer.appendChild(createMetricPillElement('SPA route active', '🔄'));
  }
}

function requestPageStatus(attempt = 0) {
  if (!currentTab?.id || !currentTab.url || !/^https?:\/\//i.test(currentTab.url)) {
    renderUnsupportedStatus();
    return;
  }
  sendTabMessage(currentTab.id, { type: 'GET_STATUS' }).then(({ response, error }) => {
    if (!error && response?.status === 'initializing' && attempt < 8) {
      window.setTimeout(() => requestPageStatus(attempt + 1), 125);
      return;
    }
    if (!error && response?.status === 'initializing') {
      renderReloadStatus();
      return;
    }
    if (error || !response?.status) {
      if (!getSiteState().enabled) renderSiteOffStatus();
      else renderReloadStatus();
      return;
    }

    statusDot.className = response.enabled ? 'status-dot is-active' : 'status-dot is-muted';
    statusPage.textContent = response.enabled ? 'Active' : 'Off for this site';
    if (!response.enabled) {
      statusDetail.textContent = 'SmoothBoost is loaded, but paused for this site.';
    } else if (response.motionPreserved) {
      statusDetail.textContent = response.offscreenAnimationsPaused
        ? 'Visible animations stay active; offscreen loops pause to save work. The site’s Reduce motion setting remains in control.'
        : 'Page animations stay under the site’s Reduce motion setting.';
    } else if (response.archetype === 'realtime-app') {
      statusDetail.textContent = response.mode === 'custom'
        ? 'Live communication app detected. Calls stay protected; Custom animation settings apply.'
        : 'Live communication app detected. Chat, calls, and interface motion stay active while safe scroll handling remains on.';
    } else if (response.mode === 'auto' && response.archetype === 'interactive-canvas') {
      statusDetail.textContent = 'Smart Auto: Interactive canvas app detected. Bypassing canvas throttling to ensure full input responsiveness.';
    } else if (response.mode === 'auto') {
      statusDetail.textContent = 'Smart Auto: Running verified heuristics for responsive browsing.';
    } else {
      statusDetail.textContent = 'SmoothBoost is running in this tab.';
    }

    const modeLabels = { auto: 'Smart Auto', ultra: 'Maximum', balanced: 'Balanced', battery: 'Battery Saver', custom: 'Custom' };
    statusProfile.textContent = response.enabled ? (modeLabels[response.mode] || 'Custom') : 'Off';

    const onReanime = Boolean(response.siteRule && response.siteRule !== 'not-applicable');
    if (siteRuleRow) {
      siteRuleRow.hidden = !onReanime;
      if (siteRuleRow.style) siteRuleRow.style.display = onReanime ? 'flex' : 'none';
      if (onReanime) renderRuleStatus(response.siteRule);
    }

    if (autoRecoveryBanner) {
      const showRecovery = Boolean(response.autoRecovery?.active);
      autoRecoveryBanner.hidden = !showRecovery;
      if (autoRecoveryBanner.style) autoRecoveryBanner.style.display = showRecovery ? 'flex' : 'none';
    }

    // Request actual optimizer metrics
    sendTabMessage(currentTab.id, { type: 'GET_METRICS' }).then(({ response: metricsResp }) => {
      if (metricsResp?.metrics) renderMetricsPills(metricsResp.metrics);
    });
  });
}

function sendTabMessage(tabId, message) {
  return new Promise((resolve) => {
    try {
      chrome.tabs.sendMessage(tabId, message, { frameId: 0 }, (response) => {
        const error = chrome.runtime.lastError;
        resolve({ response, error });
      });
    } catch (err) {
      resolve({ response: null, error: err });
    }
  });
}

function buildIssueUrl(siteBroken) {
  const profile = getSiteState().mode || 'unknown';
  const browser = typeof navigator !== 'undefined' ? (navigator.userAgent || 'Unknown browser') : 'Unknown browser';
  const title = siteBroken ? `[Bug] Site looks broken on ${currentHostname || 'this page'}` : '[Bug] SmoothBoost issue';
  const body = [
    '## Page details',
    `- Site: ${currentHostname || 'unknown'}`,
    `- Profile: ${profile}`,
    `- Browser: ${browser}`,
    siteBroken ? '- SmoothBoost was turned off for this site from the popup.' : '',
    '',
    '## What happened?',
    '',
    '## Steps to reproduce',
    '1. ',
    '',
    '## Expected result',
    '',
    '## Actual result',
    ''
  ].filter(Boolean).join('\n');
  return `${GITHUB_ISSUE_URL}?title=${encodeURIComponent(title)}&body=${encodeURIComponent(body)}`;
}

function bindEvents() {
  if (controlsTab) controlsTab.addEventListener('click', () => selectTab('controls'));
  if (helpTab) helpTab.addEventListener('click', () => selectTab('help'));
  if (checkUpdatesButton) checkUpdatesButton.addEventListener('click', () => { void checkForUpdates(true); });

  siteToggle.addEventListener('change', () => {
    updateSiteOverride({ enabled: siteToggle.checked });
    renderUI();
    saveAndBroadcast();
  });

  if (btnAuto) btnAuto.addEventListener('click', () => setMode('auto'));
  if (btnUltra) btnUltra.addEventListener('click', () => setMode('ultra'));
  if (btnBalanced) btnBalanced.addEventListener('click', () => setMode('balanced'));
  if (btnBattery) btnBattery.addEventListener('click', () => setMode('battery'));
  if (btnCustom) btnCustom.addEventListener('click', () => setMode('custom'));

  if (btnExportSettings) {
    btnExportSettings.addEventListener('click', exportSettings);
  }

  if (btnImportSettings && inputImportSettings) {
    btnImportSettings.addEventListener('click', () => {
      inputImportSettings.value = '';
      inputImportSettings.click();
    });
    inputImportSettings.addEventListener('change', (e) => {
      const file = e.target.files?.[0];
      if (file) void importSettingsFile(file);
    });
  }

  if (shortcutTip) {
    const isTouch = window.matchMedia && window.matchMedia('(pointer: coarse)').matches;
    const isMobile = (typeof SmoothBoostCompat !== 'undefined' && SmoothBoostCompat.isMobile)
      || (typeof navigator !== 'undefined' && /android|iphone|ipad|ipod|mobile/i.test(navigator.userAgent || ''));
    if (isTouch || isMobile || !chrome?.commands) {
      shortcutTip.hidden = true;
      if (shortcutTip.style) shortcutTip.style.display = 'none';
    }
  }

  if (btnAcceptAuto) {
    btnAcceptAuto.addEventListener('click', () => {
      config.showAutoPromo = false;
      if (autoPromoBanner) {
        autoPromoBanner.hidden = true;
        if (autoPromoBanner.style) autoPromoBanner.style.display = 'none';
      }
      setMode('auto');
    });
  }

  if (btnDismissAuto) {
    btnDismissAuto.addEventListener('click', () => {
      config.showAutoPromo = false;
      if (autoPromoBanner) {
        autoPromoBanner.hidden = true;
        if (autoPromoBanner.style) autoPromoBanner.style.display = 'none';
      }
      chrome.storage.local.set({ smoothBoostConfig: config });
    });
  }

  if (updateNotificationDismiss && updateNotificationBanner) {
    updateNotificationDismiss.addEventListener('click', () => {
      updateNotificationBanner.hidden = true;
      if (updateNotificationBanner.style) updateNotificationBanner.style.display = 'none';
    });
  }

  if (btnResetRecovery) {
    btnResetRecovery.addEventListener('click', async () => {
      if (currentTab?.id) {
        await sendTabMessage(currentTab.id, { type: 'RESET_AUTO_RECOVERY' });
        if (autoRecoveryBanner) {
          autoRecoveryBanner.hidden = true;
          if (autoRecoveryBanner.style) autoRecoveryBanner.style.display = 'none';
        }
        requestPageStatus();
      }
    });
  }

  Object.entries(fpsButtons).forEach(([fps, btn]) => {
    if (btn) btn.addEventListener('click', () => setFpsLimit(Number(fps)));
  });

  [
    [toggleAnim, 'killAnimations'],
    [toggleTrans, 'killTransitions'],
    [toggleBlur, 'killBlurFilters'],
    [toggleScroll, 'killScrollHijack'],
    [toggleMedia, 'pauseBackgroundMedia'],
    [toggleFps, 'throttleCanvasFps'],
    [toggleOffscreen, 'pauseOffscreenAnimations'],
    [toggleContentVisibility, 'contentVisibility'],
    [toggleOffscreenCanvas, 'pauseOffscreenCanvas'],
    [togglePassiveScroll, 'passiveScroll'],
    [toggleAsyncImages, 'asyncImageDecoding'],
    [toggleScrollBoost, 'scrollBoost'],
    [toggleSmartResources, 'smartResourceLoading'],
    [toggleMemoryGuard, 'memoryGuard'],
    [toggleSpaOptimization, 'spaOptimization'],
    [toggleAutoRecovery, 'autoRecovery']
  ].forEach(([input, key]) => {
    if (input) input.addEventListener('change', () => setCustomSetting(key, input.checked));
  });

  if (siteBrokenButton) {
    siteBrokenButton.addEventListener('click', async () => {
      if (!currentHostname || !currentTab?.id) return;
      updateSiteOverride({ enabled: false });
      renderUI();

      // Purge cached archetype so a bad guess doesn't stick
      try {
        await chrome.runtime.sendMessage({ type: 'PURGE_ARCHETYPE', hostname: currentHostname });
      } catch (_e) {}

      await saveAndBroadcast();

      // Reload tab to instantly restore original site appearance
      try {
        await chrome.tabs.reload(currentTab.id);
      } catch (_e) {}
    });
  }

  if (bugReportLink) {
    bugReportLink.addEventListener('click', (event) => {
      event.preventDefault();
      chrome.tabs.create({ url: buildIssueUrl(false) });
    });
  }

  if (resetBtn) {
    resetBtn.addEventListener('click', async () => {
      config = JSON.parse(JSON.stringify(DEFAULT_SETTINGS));
      renderUI();
      await saveAndBroadcast();
    });
  }
}

function selectTab(tabName) {
  const showControls = tabName === 'controls';
  if (controlsTab) {
    controlsTab.classList.toggle('is-selected', showControls);
    controlsTab.setAttribute('aria-selected', String(showControls));
    controlsTab.tabIndex = showControls ? 0 : -1;
  }
  if (helpTab) {
    helpTab.classList.toggle('is-selected', !showControls);
    helpTab.setAttribute('aria-selected', String(!showControls));
    helpTab.tabIndex = showControls ? -1 : 0;
  }
  if (controlsPanel) controlsPanel.hidden = !showControls;
  if (helpPanel) helpPanel.hidden = showControls;
}

function exportSettings() {
  const exportPayload = {
    app: 'SmoothBoost',
    version: chrome?.runtime?.getManifest ? (chrome.runtime.getManifest()?.version || '2.1.0') : '2.1.0',
    exportedAt: new Date().toISOString(),
    config: {
      settingsVersion: config?.settingsVersion || 4,
      globalEnabled: config?.globalEnabled !== false,
      mode: config?.mode || 'auto',
      customSettings: { ...DEFAULT_SETTINGS.customSettings, ...(config?.customSettings || {}) },
      siteOverrides: config?.siteOverrides || {}
    }
  };
  const jsonStr = JSON.stringify(exportPayload, null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  const dateStr = new Date().toISOString().slice(0, 10);
  a.href = url;
  a.download = `smoothboost-settings-${dateStr}.json`;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => {
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, 100);
}

function validateImportedSettings(parsed) {
  if (!parsed || typeof parsed !== 'object') {
    throw new Error('Invalid JSON: expected a root object.');
  }
  const rawConfig = parsed.config && typeof parsed.config === 'object' ? parsed.config : parsed;
  const validModes = ['auto', 'ultra', 'balanced', 'battery', 'custom'];

  const validated = {
    settingsVersion: 4,
    globalEnabled: rawConfig.globalEnabled !== false,
    mode: validModes.includes(rawConfig.mode) ? rawConfig.mode : 'auto',
    showAutoPromo: false,
    customSettings: { ...DEFAULT_SETTINGS.customSettings },
    siteOverrides: {}
  };

  if (rawConfig.customSettings && typeof rawConfig.customSettings === 'object') {
    for (const [key, defVal] of Object.entries(DEFAULT_SETTINGS.customSettings)) {
      if (typeof defVal === 'boolean' && typeof rawConfig.customSettings[key] === 'boolean') {
        validated.customSettings[key] = rawConfig.customSettings[key];
      } else if (typeof defVal === 'number' && typeof rawConfig.customSettings[key] === 'number') {
        validated.customSettings[key] = Math.max(10, Math.min(120, rawConfig.customSettings[key]));
      }
    }
  }

  if (rawConfig.siteOverrides && typeof rawConfig.siteOverrides === 'object') {
    for (const [hostname, site] of Object.entries(rawConfig.siteOverrides)) {
      if (typeof hostname === 'string' && hostname.trim() && site && typeof site === 'object') {
        const cleanHost = hostname.trim().toLowerCase();
        if (cleanHost === '__proto__' || cleanHost === 'prototype' || cleanHost === 'constructor') {
          continue;
        }
        const cleanSite = {};
        if (typeof site.enabled === 'boolean') cleanSite.enabled = site.enabled;
        if (validModes.includes(site.mode)) cleanSite.mode = site.mode;
        if (site.customSettings && typeof site.customSettings === 'object') {
          cleanSite.customSettings = {};
          for (const [key, defVal] of Object.entries(DEFAULT_SETTINGS.customSettings)) {
            if (typeof defVal === 'boolean' && typeof site.customSettings[key] === 'boolean') {
              cleanSite.customSettings[key] = site.customSettings[key];
            } else if (typeof defVal === 'number' && typeof site.customSettings[key] === 'number') {
              cleanSite.customSettings[key] = Math.max(10, Math.min(120, site.customSettings[key]));
            }
          }
        }
        validated.siteOverrides[cleanHost] = cleanSite;
      }
    }
  }

  return validated;
}

async function importSettingsFile(file) {
  if (!file) return;
  try {
    const text = await file.text();
    const parsed = JSON.parse(text);
    const validConfig = validateImportedSettings(parsed);
    config = validConfig;
    renderUI();
    await saveAndBroadcast();
    showSettingsStatus('Settings imported successfully!', 'success');
  } catch (err) {
    showSettingsStatus('Failed to import: ' + (err.message || 'invalid file format'), 'error');
  }
}

function showSettingsStatus(msg, type = 'info') {
  if (!settingsStatus) return;
  settingsStatus.textContent = msg;
  settingsStatus.className = 'settings-status is-' + type;
  settingsStatus.hidden = false;
  setTimeout(() => {
    if (settingsStatus) settingsStatus.hidden = true;
  }, 4000);
}

document.addEventListener('DOMContentLoaded', init);

if (typeof module === 'object' && module.exports) {
  module.exports = {
    DEFAULT_SETTINGS,
    PRESET_CONFIGS,
    validateImportedSettings
  };
}
